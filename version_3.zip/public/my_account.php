<?php require_once("../includes/connection.php") ?>

<?php
//start session before anything else
  session_start();
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../css/favicon.ico">

    <title>My Account</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/justified-nav.css" rel="stylesheet">

  </head>

  <body>

    <div class="container">

      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
        <h3 class="text-muted"><?php
    echo "You are logged in as " . $_SESSION["firstname"] . " " . $_SESSION["lastname"] . "";
    ?></h3>
        <nav>
          <ul class="nav nav-justified">
            <!-- <li class="active">Search<a href="#"></a></li> -->
            <li><a href="index.php">Search</a></li>
            <li><a href="auctioned_items.php">Auctioned Items</a></li>
            <li><a href="unauctioned_items.php">Non-Auctioned Items</a></li>
            <li><a href="#">Sold Items</a></li>
            <li><a href="#">Bought Items</a></li>
            <li><a href="#">My Bids</a></li>
            <li><a href="#">Watchlist</a></li>
          </ul>
        </nav>
      </div>

      <!-- Jumbotron -->
      <div class="jumbotron">
        <h1>Cool Crew Auction</h1>
        <p class="lead">Search items you fancy!</p>
            <input type="text" class="form-control" placeholder="Search for...">
          </br>
            <button class="btn dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> Categories
            <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Something else here</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="#">Separated link</a></li>
            </ul>
        </br>
        </br>
        <p><a class="btn btn-lg btn-success" href="#" role="button">Search</a></p>
      </div>

      <?php

//display live auctions on homepage
  $auctions_home = "SELECT items.item_name, items.item_description FROM items INNER JOIN auction ON auction.item_id = items.item_id";
  $result_auctions_home = mysqli_query($conn,$auctions_home);

    if (mysqli_num_rows($result_auctions_home) > 0) {
      while ($row = mysqli_fetch_assoc($result_auctions_home)) {
        echo "<div class=\"row\">";
        echo "<div class=\"col-lg-4\">";
        echo "<h2>" . $row["item_name"]. "</h2>";
        echo "<p>" . $row["item_description"]. "</p>";
        echo "<p><a class=\"btn btn-primary\" href=\"sign_in.php\" role=\"button\">View details &raquo;</a></p>";
        echo "</div>";
        echo "</div>";
        // echo "item name: " . $row["item_name"]. " - item description: " . $row["item_description"]. " <br>";
      }
      //define session variables to be retrieved
      // $_SESSION["item_name"] = $row_auctions_home["user_fname"];
      // $_SESSION["item_descrp"] = $row_auctions_home["user_lname"];
      // header('Location: index.php');
      // exit();
    } else {
      echo "No live auctions";
    }


// close connection
  mysqli_close($conn);
?>

      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2016 Cool Crew Company, Inc.</p>
      </footer>

    </div> <!-- /container -->

  </body>
</html>
