<?php
//start session before anything else
  session_start();

  // errors print
  // ini_set('display_errors', 1);
  // ini_set('display_startup_errors', 1);
  // error_reporting(E_ALL);

  // function isLoggedIn() {return isset($_SESSION['user_id']);}
//    if (isLoggedIn()) {
//      echo 'You are logged in as "' . $_SESSION['username']. '".';
//    }
?>