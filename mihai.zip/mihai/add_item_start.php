<?php include("C:\wamp64\www\site\admin/db_connection.php"); ?>
<?php require_once("C:\wamp64\www\site\admin/functions.php"); ?>

<html>
<body>
<?php
$categoryname = "SELECT category_name, category_id FROM item_category";
$c_query = mysqli_query($connection, $categoryname);
// set array
$array = array();
// look through query
while($row = mysql_fetch_assoc($c_query)){
	// add each row returned into an array
  $array[] = $row;}

?>

<form action="add_item_load.php" method="post">
Item name <input type="text" name="item-name"><br>
Item decription <input type="text" name="item-description"><br>
URL to item image <input type="text" name="item-image"><br>

<?php
$categoryname = "SELECT category_name, category_id FROM item_category";
$c_query = mysqli_query($connection, $categoryname);
// set array
$array = array();
// look through query
while($row = mysqli_fetch_assoc($c_query)){
	// add each row returned into an array
  $array[] = $row;}?>

<select name="item-category">
	    <option value="">Select a category</option>
		 <?php foreach($array as $item) {?>

			<option value="<?php echo $item["category_id"]; ?>"><?php echo $item["category_name"]; ?></option>
		<?php };//test whether that variable has anything in it?>

<button type="Submit" name="submit-item">Add item</button>

</form>
</body>
</html>


<?php include("C:\wamp64\www\site\admin/footer.php"); ?>