

<?php include("C:\wamp64\www\site\admin/db_connection.php"); ?>
<?php require_once("C:\wamp64\www\site\admin/functions.php"); ?>

<html>
<body>

<form action="create_auction_load.php" method="post">
Start date: <input type="date" name="start-date"><br/>
Start time: <input type="time" name="start-time"><br/>
End date: <input type="date" name="end-date"><br/>
End time: <input type="time" name="end-time"><br/>
Start price: <input type="number" name="start-price"><br/>
<button type="submit" name="create-auction">Create auction</button>

</form>


</body>
</html>


<?php include("C:\wamp64\www\site\admin/footer.php"); ?>