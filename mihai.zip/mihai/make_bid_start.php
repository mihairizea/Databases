<?php include("C:\wamp64\www\site\admin/db_connection.php"); ?>
<?php require_once("C:\wamp64\www\site\admin/functions.php"); ?>

<html>
<body>

<form action="make_bid_load.php" method="post">
Value you want to pay: <input type="number" name="bid-value"><br/>
<!-- NEED TO PUT A CHECK HERE THAT THE VALUE INPUTED IS LARGER THAN THE VALUE OF THE LAST BID AND THAT OF THE STARTING PRICE -->
<button type="submit" name="make-bid">Submit bid</button>
</form>

</body>
</html>


<?php include("C:\wamp64\www\site\admin/footer.php"); ?>