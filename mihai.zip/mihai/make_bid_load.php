<!--$var = date("Y-m-d h:i:s");-->
<?php include("C:\wamp64\www\site\admin/db_connection.php"); ?>
<?php require_once("C:\wamp64\www\site\admin/functions.php"); ?>

<html>
<body>

<?php
$auction_id = 1; // will come from menu page
// ad a field here that selects the name of the item being 
// bidded upon from the database (use auction id to get item id to get item name)

$bid_value = $_POST["bid-value"];//comes from post
$bid_time = date("Y-m-d H:i:s"); 
$bidder_id = 10; // the bidder, will come from session
//echo $bid_time;

$make_bid_query = "INSERT INTO bid (auction_id, bid_value, bid_time, bidder_id) 
VALUES ({$auction_id}, {$bid_value}, '{$bid_time}', {$bidder_id})";

$result = mysqli_query($connection, $make_bid_query);
//Test if there was a query error 
if ($result){
	//Success
	//redirect_to("my_items.php");
} else {
	$message = "Information missing or identical bid already placed";
	echo $message;}

?>

<?php
$last_bid = "SELECT bid_id FROM bid ORDER BY bid.bid_time DESC LIMIT 1" ;

$last_bid2 = mysqli_query($connection, $last_bid);
$row = mysqli_fetch_assoc($last_bid2);

$converter = $row["bid_id"];


$add_last_bid = "UPDATE auctions SET last_bid_id = {$converter} WHERE auction_id = {$auction_id}";
$add_last_bid2 = mysqli_query($connection, $add_last_bid);
?>

</body>
</html>


<?php include("C:\wamp64\www\site\admin/footer.php"); ?>