<?php include("C:\wamp64\www\site\admin/db_connection.php"); ?>
<?php require_once("C:\wamp64\www\site\admin/functions.php"); ?>

<html>
<body>


<?php 
$item_name = $_POST["item-name"];
$item_description = $_POST["item-description"];
$image =  $_POST["item-image"];
$category_id = $_POST["item-category"]; //will be a query that finds the category id in the database based on the category name from the form
$user_id = 69;//will come from the session

 
//Perform database query

$add_item_query = "INSERT INTO item (user_id, item_description, item_name, image, category_id) 
VALUES ({$user_id}, '{$item_description}', '{$item_name}', '{$image}', {$category_id})";

$result = mysqli_query($connection, $add_item_query);
//Test if there was a query error 
if ($result){
	//Success
	//redirect_to("my_items.php");
} else {
	$message = "Information missing or item has already been added";
	echo $message;
}

?>

</body>
</html>


<?php include("C:\wamp64\www\site\admin/footer.php"); ?>