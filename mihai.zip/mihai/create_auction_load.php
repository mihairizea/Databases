<!--$var = date("Y-m-d h:i:s");-->
<?php include("C:\wamp64\www\site\admin/db_connection.php"); ?>
<?php require_once("C:\wamp64\www\site\admin/functions.php"); ?>

<html>
<body>


<?php 
// echo $_POST["start-date"]; echo "   ";
// echo $_POST["start-time"];echo "   ";
// echo $_POST["end-date"];echo "   ";
// echo $_POST["end-time"];echo "   ";
$item_id = 27; //will comefrom session later
$start_time = $_POST["start-date"] . " " . $_POST["start-time"];
$start_time = date($start_time);
$end_time = $_POST["end-date"] . " " . $_POST["end-time"];
$start_time = date($end_time);
$start_price = $_POST["start-price"];


$create_auction_query = "INSERT INTO auctions (item_id, start_time, end_time, start_price) 
VALUES ({$item_id}, '{$start_time}', '{$end_time}', {$start_price})";


$result = mysqli_query($connection, $create_auction_query);
//Test if there was a query error 
if ($result){
	//Success
	//redirect_to("my_items.php");
} else {
	$message = "Information missing or auction has already been started";
	echo $message;
}

?>



</body>
</html>


<?php include("C:\wamp64\www\site\admin/footer.php"); ?>