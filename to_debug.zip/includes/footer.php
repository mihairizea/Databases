 <?php
// close connection
  mysqli_close($conn);
?>

 <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2016 Cool Crew Company, Inc.</p>
      </footer>

    </div> <!-- /container -->


