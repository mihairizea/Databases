<?php require_once("../includes/connection.php") ?>

<?php
//start session before anything else
  session_start();
  // ini_set('display_errors', 1);
  // ini_set('display_startup_errors', 1);
  // error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../css/favicon.ico">

    <title>My Account</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/justified-nav.css" rel="stylesheet">

  </head>

  <body>

    <div class="container">

      <!-- NAVBAR -->
      <div class="masthead">

        <!-- USER-SESSION DETAILS -->
        <h3 class="text-muted"><?php echo "You are logged in as " . $_SESSION["firstname"] . " " . $_SESSION["lastname"] . ""; ?></h3>

        <!-- TABS -->
        <nav>
          <ul class="nav nav-justified">
            <li><a href="my_account.php">Search</a></li>
            <li><a href="unauctioned_items.php">Unauctioned Items</a></li>
            <li><a href="auctioned_items.php">Auctioned Items</a></li>
            <li><a href="sold_items.php">Sold Items</a></li>
            <li><a href="bought_items.php">Bought Items</a></li>
            <li><a href="my_bids.php">My Bids</a></li>
            <li><a href="watch.php">Watchlist</a></li>
          </ul>
        </nav>
      </div>

      <!-- HOMEPAGE -->
      <div class="jumbotron">
        <h1>Cool Crew Auction</h1></br></br>

        <!-- ADD NEW ITEM -->
      <p><a class="btn btn-lg btn-danger" href="add_item_start.php" role="button">Add Item</a></p>
      </div>
      </br>
      </br>

        <p class="lead">Search items you fancy!</p>
            
            <!-- SEARCH BAR -->
            <form action="" method="get" autocomplete="on">

            <!-- <input type="text" class="form-control" id="item" name="item" placeholder="Search for..."></br> -->
            <input  type="text" id="item" name="item" placeholder="Search item" /></br></br>


            <!-- DROPDOWN -->
            <div>
              <?php
              $dropdown_query = "SELECT cat_name, cat_id FROM item_category";
              $result = mysqli_query($conn, $dropdown_query);?>

              <select name="categorylist">
                <option value="">Select a category</option>
                <?php while ($row = $result->fetch_assoc()) {?>
                <option value="<?php echo $row["cat_id"]; ?>"><?php echo $row["cat_name"]; ?></option>
                <?php }; ?>
              </select>
              
              </br>
              </br>

              <input type="submit" value="Search">
            </div>

            </br>
            </br>

            <!-- PHP SEARCH -->
            <?php

            // DISPLAY DEFAULT ITEMS IN AUCTION TABLE
            if (empty($_GET['item']) && empty($_GET['categorylist'])) {

              $auctions_home = "SELECT * FROM items INNER JOIN auction ON auction.item_id = items.item_id WHERE auction.closed = '0'";
              $result_auctions_home = mysqli_query($conn,$auctions_home);

              if (mysqli_num_rows($result_auctions_home) > 0) {
                while ($row = mysqli_fetch_assoc($result_auctions_home)) {
                  echo "<div class=\"row\">";
                  echo "<div class=\"col-lg-4\">";
                  $image = $row["image"];
                  $id = $row["item_id"];
                  echo "<img src=\"$image\" style=\"width:128px;height:128px;\">";
                  echo "<a href=\"auction.php?id=$id\"><h2>" . $row["item_name"]. "</h2></a>";
                  echo "<p>" . $row["item_description"]. "</p>";
                  echo "</div>";
                  echo "</div>";
                }
              } else {
                echo "No live auctions";
              }
            }

            // SELECT CATEGORY AND ENTER SEARCH TERM CASE
            if (!empty($_GET['item']) && !empty($_GET['categorylist'])) {
              $product = mysqli_real_escape_string($conn, $_GET['item']);
              $categorylist = mysqli_real_escape_string($conn, $_GET['categorylist']);
              $product_query = "SELECT * FROM items INNER JOIN item_category ON items.category_id=item_category.cat_id INNER JOIN auction ON auction.item_id = items.item_id WHERE auction.closed = '0' AND items.category_id= '$categorylist' AND item_name LIKE '%".$product."%'";
              $result_product_query = mysqli_query($conn, $product_query);
            }
            
            // SELECT CATEGORY ONLY CASE
            elseif  (!empty($_GET['categorylist'])) {
              $categorylist = mysqli_real_escape_string($conn, $_GET['categorylist']);
              $product_query = "SELECT * FROM items INNER JOIN item_category ON items.category_id=item_category.cat_id INNER JOIN auction ON auction.item_id = items.item_id WHERE auction.closed = '0' AND items.category_id=".$categorylist;
              $result_product_query = mysqli_query($conn, $product_query);
            }

            // ENTER SEARCH TERM ONLY CASE
            elseif (!empty($_GET['item'])) {
              $product = mysqli_real_escape_string($conn, $_GET['item']);
              $product_query = "SELECT * FROM items INNER JOIN item_category ON items.category_id=item_category.cat_id INNER JOIN auction ON auction.item_id = items.item_id WHERE auction.closed = '0' AND item_name LIKE '%".$product."%'";
              $result_product_query = mysqli_query($conn, $product_query);
            }

            // SEARCH KEY DOESN'T MATCH SELECTED CATEGORY
            if (mysqli_num_rows($result_product_query)==0 && isset($_GET["categorylist"])) {
              echo "<div class=\"row\">";
              echo "<div class=\"col-lg-4\">";
              echo "<b>No results</b>";
              echo "</div>";
              echo "</div>";
            }

         
            // DISPLAY RESULTS
            while ($row = mysqli_fetch_assoc($result_product_query)) {

              echo "<div class=\"row\">";
              echo "<div class=\"col-lg-4\">";
              $image = $row["image"];
              echo "<img src=\"$image\" style=\"width:128px;height:128px;\">";
              echo "<a href=\"auction.php?id=$id\"><h2>" . $row["item_name"]. "</h2></a>";
              echo "<p>" . $row["item_description"]. "</p>";
              echo "</div>";
              echo "</div>";
            }; 

            ?>

             </form>

      </br>
      </br>


<?php require_once("../includes/footer.php") ?>

  </body>
</html>
