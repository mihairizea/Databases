<?php require_once("../includes/connection.php") ?>
<?php
//start session before anything else
  session_start();

  // errors print
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../css/favicon.ico">

    <?php echo "<title>" . $_GET["id"] . "</title>"?>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/justified-nav.css" rel="stylesheet">

  </head>

  <body>

    <?php
      $queryString = "SELECT * FROM items WHERE item_id = " . $_GET["id"];
      $item = mysqli_fetch_assoc(mysqli_query($conn, $queryString));
    ?>

    <div class="row">
      <div class="col-lg-4 col-md-offset-4">
        <?php
        $image = $item["image"];
        echo "<img src=\"$image\" style=\"width:128px;height:128px;\">";?>
        <h2><?php echo $item["item_name"] ?></h2>
        <p><?php echo $item["item_description"] ?></p>
      </div>
    </div>

    <div class="container">

    	<div class="jumbotron">


        <!-- ADD NEW ITEM -->
      <!-- <p><a class="btn btn-lg btn-success" href="" role="button">Add to Watchlist</a></p> -->

      </br>

        <div>

          <?php

          

          // RETRIEVE AUCTION ID
          $queryString = "SELECT auction_id FROM auction WHERE item_id = " . $_GET["id"];
          $auction_id = mysqli_fetch_assoc(mysqli_query($conn, $queryString))["auction_id"];

        
              

          ?>



<?php require_once("../includes/footer.php") ?>

  </body>
</html>


