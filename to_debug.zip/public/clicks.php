<?php require_once("../includes/connection.php") ?>
 
<?php

// errors print
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);
 
 $id = $_GET["id"];
 $sql="UPDATE AUCTION.auction SET viewings = viewings+1 WHERE auction_id =" . $_GET["id"];
 $result=mysqli_query($conn,$sql);
 header("Location: auction.php?id=$id");
 exit;

?>