<?php require_once("../includes/connection.php") ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../css/favicon.ico">

    <title> Sold Items </title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/justified-nav.css" rel="stylesheet">

  </head>

  <body>

    <div class="container">

      <!-- NAVBAR -->
      <div class="masthead">

        <!-- USER-SESSION DETAILS -->
        <h3 class="text-muted"><?php echo "You are logged in as " . $_SESSION["firstname"] . " " . $_SESSION["lastname"] . ""; ?></h3>

        <!-- TABS -->
        <nav>
          <ul class="nav nav-justified">
            <li><a href="my_account.php">Search</a></li>
            <li><a href="unauctioned_items.php">Unauctioned Items</a></li>
            <li><a href="auctioned_items.php">Auctioned Items</a></li>
            <li><a href="sold_items.php">Sold Items</a></li>
            <li><a href="bought_items.php">Bought Items</a></li>
            <li><a href="my_bids.php">My Bids</a></li>
            <li><a href="watch.php">Watchlist</a></li>
          </ul>
        </nav>
      </div>

    	<div class="jumbotron">
        <h1>Sold Items</h1>
      </div>

      <?php

      // RETRIEVE ITEMS SUCCESSFULLY SOLD BY USER
      $my_items = "SELECT * FROM items INNER JOIN auction ON auction.item_id = items.item_id WHERE auction.closed = 1 AND items.user_id = ". $_SESSION["ID"] ."";
      $result_my_items = mysqli_query($conn,$my_items);
    
      if (mysqli_num_rows($result_my_items) > 0) {
      while ($row = mysqli_fetch_assoc($result_my_items)) {
        echo "<div class=\"row\">";
        echo "<div class=\"col-lg-4\">";
        $image = $row["image"];
        $id = $row["item_id"];
        echo "<img src=\"$image\" style=\"width:128px;height:128px;\">";
        echo "<a href=\"auction.php?$id\"><h2>" . $row["item_name"]. "</h2></a>";
        echo "<p>" . $row["item_description"]. "</p>";
        echo "</div>";
        echo "</div>";
      } 
      } else {
      echo "No items sold yet";
      }


      ?>

      <?php require_once("../includes/footer.php") ?>

  </body>
</html>
